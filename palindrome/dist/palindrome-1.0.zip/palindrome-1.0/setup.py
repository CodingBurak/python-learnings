from distutils.core import setup

setup(
  name="palindrome",
  version= "1.0",
  py_modules= ["palindrome"], #without py endings!
  author="burakk",
  author_email="mail",
  description="test",
  license="public",
  keywords="setup"
)